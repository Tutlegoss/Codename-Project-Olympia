Deliverable #7 (10%) - Required Readme file - Prepare a small �Readme� file in which
you discuss your experience in the group so far. Include any alternative decisions that
you had to make, or issues that you faced, or domain analysis decisions that changed over
time. Also indicate how the work has been distributed in the group and how the
teamwork has been organized. If changes have occurred over time indicate the data of the
change. The ReadMe file should also guide the instructor through the final folder report
that contains all the deliverables by providing and index (for example, the list of the
folder and what each folder contain) and indicate any information that many be necessary
to communicate to the instructor while reading the final report of the deliverables. Add
any information generated in the template report that has been given to you in the part 1
of the project. 