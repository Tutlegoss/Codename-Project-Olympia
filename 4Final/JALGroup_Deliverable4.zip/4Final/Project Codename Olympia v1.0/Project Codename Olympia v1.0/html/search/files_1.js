var searchData=
[
  ['display_2ecs',['Display.cs',['../Display_8cs.html',1,'']]],
  ['display_2edesigner_2ecs',['Display.Designer.cs',['../Display_8Designer_8cs.html',1,'']]]
];
