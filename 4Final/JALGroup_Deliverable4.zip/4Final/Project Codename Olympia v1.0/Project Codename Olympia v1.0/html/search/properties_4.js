var searchData=
[
  ['score',['score',['../classScoring.html#a98cbf9ebbee504f67d1ebcbb45f3bf40',1,'Scoring']]]
];
