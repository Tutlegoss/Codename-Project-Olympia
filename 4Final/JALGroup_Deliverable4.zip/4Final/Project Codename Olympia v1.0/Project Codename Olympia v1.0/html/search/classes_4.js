var searchData=
[
  ['pairskating',['PairSkating',['../classPairSkating.html',1,'']]]
];
