var searchData=
[
  ['judge_2ecs',['Judge.cs',['../Judge_8cs.html',1,'']]],
  ['judge_2edesigner_2ecs',['Judge.Designer.cs',['../Judge_8Designer_8cs.html',1,'']]]
];
