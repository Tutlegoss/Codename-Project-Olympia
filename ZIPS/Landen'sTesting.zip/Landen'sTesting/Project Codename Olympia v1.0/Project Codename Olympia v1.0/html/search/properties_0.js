var searchData=
[
  ['countryname',['countryName',['../classTeam.html#abe0a9396e60ebf155cf10c0700214753',1,'Team']]]
];
