var searchData=
[
  ['place',['Place',['../classPCO_1_1__0_1_1ScoringForm.html#a032fbd87d18a6e0907a83c282e4f2560',1,'PCO::_0::ScoringForm']]]
];
