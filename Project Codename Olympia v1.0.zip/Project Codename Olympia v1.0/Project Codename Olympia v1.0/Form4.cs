﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace Project_Codename_Olympia_v1._0
{
    public partial class RegisterEventForm : Form
    {
        public RegisterEventForm()
        {
            InitializeComponent();
        }

        private void RegisterEventForm_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("Mens 500m Speed Skating, Monday, 12:00pm, Rink 1");
            listBox1.Items.Add("Womens 500m Speed Skating, Monday, 12:00pm Rink 2");
            listBox1.Items.Add("Mens 1000m Speed Skating, Tueday, 12:00pm, Rink 1");
            listBox1.Items.Add("Womens 1000m Speed Skating, Tuesday, 12:00pm, Rink 2");
            listBox1.Items.Add("Mens 1500m Speed Skating, Wednesday, 12:00pm, Rink 1");
            listBox1.Items.Add("Womens 1500m Speed Skating, Wednesday, 12:00pm, Rink 2");
            listBox1.Items.Add("Single Skating Mens, Monday, 11:00am, Rink 3");
            listBox1.Items.Add("Single Skating Womens, Monday, 11:00am, Rink 4");
            listBox1.Items.Add("Ice Dance Mens, Tuesday, 2:00pm, Rink 3");
            listBox1.Items.Add("Ice Dance Womens, Tuesday, 2:00pm, Rink 4");
            listBox1.Items.Add("Couple Skating, Monday, 5:00pm, Rink 3");
            string ViewTable = "SELECT AthleteFirstName, AthleteLastName FROM 'Athlete Information'; ";//gets team table from database
            using (System.Data.SQLite.SQLiteConnection con = new System.Data.SQLite.SQLiteConnection("data source=OlympiaDB.sqlite"))
            {
                using (System.Data.SQLite.SQLiteCommand com = new System.Data.SQLite.SQLiteCommand(con))
                {
                    con.Open();//opens DB
                    if (con.State == ConnectionState.Open) // if connection.Open was successful
                    {
                        //this sends sql commands to database
                        DataSet ds = new DataSet();
                        var da = new SQLiteDataAdapter(ViewTable, con);
                        da.Fill(ds);
                        dataGridView1.DataSource = ds.Tables[0].DefaultView;
                    }
                    else
                    {
                        MessageBox.Show("Connection failed.");
                    }
                }
                con.Close();
            }
        }
    }
}
