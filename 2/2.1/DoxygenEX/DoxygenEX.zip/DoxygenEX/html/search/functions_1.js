var searchData=
[
  ['contact',['Contact',['../classContact.html#ae39444f378e6de7fd6c3e60981949af5',1,'Contact::Contact()'],['../classContact.html#a90c224b7814afe056da1a339eeab928a',1,'Contact::Contact(int area, int prefix, int suffix)']]]
];
