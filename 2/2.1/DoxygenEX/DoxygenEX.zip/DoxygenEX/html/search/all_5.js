var searchData=
[
  ['getarea',['getArea',['../classContact.html#ad8ad13da697275f7243a21132f4d7224',1,'Contact']]],
  ['getprefix',['getPrefix',['../classContact.html#afb68a34353910b2a7fb012f2c3c665c6',1,'Contact']]],
  ['getsuffix',['getSuffix',['../classContact.html#a36b4490ede1fe1114c25ecd68ba29ab1',1,'Contact']]]
];
